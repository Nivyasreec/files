import joblib
import os
import sys

# Get the absolute path to the project's root directory.
# This makes the path to the model file robust.
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
model_path = os.path.join(project_root, 'models', 'diabetes_model.pkl')

class DiabetesModel:
    """
    A class to load and use the pre-trained diabetes detection model.
    """
    def __init__(self, model_file_path):
        self.model = None
        self._load_model(model_file_path)

    def _load_model(self, model_file_path):
        """
        Loads the machine learning model from the specified file path.
        """
        try:
            self.model = joblib.load(model_file_path)
            print("Model loaded successfully!")
        except FileNotFoundError:
            print(f"Error: Model file not found at {model_file_path}")
            # Raise an exception to be caught in the main Streamlit app.
            raise FileNotFoundError("Model file not found. Please ensure 'diabetes_model.pkl' is in the 'models' folder.")
        except Exception as e:
            print(f"Error loading the model: {e}")
            raise Exception(f"An error occurred while loading the model: {e}")

    def predict(self, image_data):
        """
        Makes a prediction on the preprocessed image data.
        """
        if self.model is None:
            # If the model failed to load, return an error message.
            return "Error: Model not loaded."
        
        # Reshape the image data for a single prediction
        # Assuming your model expects a 2D array or similar format.
        # You may need to adjust the reshape based on your model's input requirements.
        # For a simple classifier, a flattened array is often used.
        # Let's flatten the image to a 1D array.
        flattened_data = image_data.reshape(1, -1)
        
        # Make a prediction
        prediction = self.model.predict(flattened_data)
        
        return prediction[0]

# Create a single, shared instance of the model.
# This ensures the model is loaded only once when the app starts.
try:
    diabetes_model_instance = DiabetesModel(model_path)
except Exception as e:
    # This will be handled by the try-except block in streamlitcode.py
    # We re-raise the error so Streamlit can display it.
    raise

