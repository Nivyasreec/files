import streamlit as st
import requests
import json
import os

# Keycloak configuration from environment variables
KEYCLOAK_URL = os.environ.get('KEYCLOAK_URL', 'http://localhost:8080/realms/your-realm')
CLIENT_ID = os.environ.get('CLIENT_ID', 'streamlit-client')
CLIENT_SECRET = os.environ.get('CLIENT_SECRET', 'your-secret')
REDIRECT_URI = "http://localhost:8501"

def get_auth_url():
    """Generates the Keycloak authorization URL."""
    auth_url = (
        f"{KEYCLOAK_URL}/protocol/openid-connect/auth?"
        f"client_id={CLIENT_ID}&"
        f"redirect_uri={REDIRECT_URI}&"
        f"response_type=code&"
        f"scope=openid profile email"
    )
    return auth_url

def get_tokens(code):
    """Exchanges the authorization code for an access token."""
    token_url = f"{KEYCLOAK_URL}/protocol/openid-connect/token"
    data = {
        "grant_type": "authorization_code",
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "code": code,
        "redirect_uri": REDIRECT_URI,
    }
    response = requests.post(token_url, data=data)
    response.raise_for_status()
    return response.json()

def get_user_info_from_token(access_token):
    """Fetches user information using the access token."""
    userinfo_url = f"{KEYCLOAK_URL}/protocol/openid-connect/userinfo"
    headers = {"Authorization": f"Bearer {access_token}"}
    response = requests.get(userinfo_url, headers=headers)
    response.raise_for_status()
    return response.json()

def login_button():
    """Creates a login button that redirects to Keycloak."""
    auth_url = get_auth_url()
    st.markdown(
        f'<a href="{auth_url}" target="_self" style="display: inline-block; padding: 12px 20px; background-color: #007bff; color: white; text-align: center; text-decoration: none; border-radius: 5px; font-size: 16px;">Log in with Keycloak</a>',
        unsafe_allow_html=True
    )
    
def get_user_info():
    """Manages the authentication flow and returns user info if authenticated."""
    query_params = st.query_params
    
    # Check if a code is present in the URL (post-redirect from Keycloak)
    if 'code' in query_params:
        try:
            tokens = get_tokens(query_params['code'])
            st.session_state.access_token = tokens['access_token']
            user_info = get_user_info_from_token(st.session_state.access_token)
            st.session_state.user_info = user_info
            
            # Clear the code from the URL to prevent re-authentication
            query_params.clear()
            st.rerun() # Rerun to remove the query parameter
            return st.session_state.user_info
        except Exception as e:
            st.error("Authentication failed.")
            st.stop()
            
    # Return user info if already authenticated
    if 'user_info' in st.session_state:
        return st.session_state.user_info
    
    return None
