import streamlit as st
import numpy as np
import pickle
import os

# Function to load the model and scaler
@st.cache_resource # Caches the function's return value to avoid reloading on every rerun
def load_assets():
    try:
        model_path = os.path.join('models', 'diabetes_model.pkl')
        scaler_path = os.path.join('models', 'scaler.pkl')
        
        with open(model_path, 'rb') as model_file:
            model = pickle.load(model_file)
        with open(scaler_path, 'rb') as scaler_file:
            scaler = pickle.load(scaler_file)
        return model, scaler
    except FileNotFoundError:
        st.error("Model or scaler file not found. Please ensure 'train_model.py' has been run and the 'models' directory exists.")
        st.stop()
        
model, scaler = load_assets()

def predict_diabetes(data):
    """Predicts diabetes risk based on input data."""
    try:
        input_array = np.asarray(data).reshape(1, -1)
        scaled_data = scaler.transform(input_array)
        prediction = model.predict(scaled_data)
        return "Diabetic" if prediction[0] == 1 else "Non-Diabetic"
    except Exception as e:
        st.error(f"Prediction failed: {e}")
        return None

# Streamlit UI
st.set_page_config(page_title="Diabetes Risk Prediction", layout="wide")
st.title("AI-Powered Diabetes Risk Prediction System 🩺")
st.header("Patient Data Input")

col1, col2, col3 = st.columns(3)
with col1:
    pregnancies = st.number_input("Number of Pregnancies", min_value=0, step=1, value=1)
    glucose = st.number_input("Glucose Level", min_value=0, step=1, value=120)
with col2:
    blood_pressure = st.number_input("Blood Pressure", min_value=0, step=1, value=70)
    skin_thickness = st.number_input("Skin Thickness", min_value=0, step=1, value=25)
with col3:
    insulin = st.number_input("Insulin Level", min_value=0, step=1, value=150)
    bmi = st.number_input("BMI", min_value=0.0, step=0.1, value=25.0)
    diabetes_pedigree = st.number_input("Diabetes Pedigree Function", min_value=0.0, step=0.01, value=0.5)
    age = st.number_input("Age", min_value=0, step=1, value=30)

input_data = [pregnancies, glucose, blood_pressure, skin_thickness, insulin, bmi, diabetes_pedigree, age]

if st.button("Predict Diabetes Risk"):
    prediction = predict_diabetes(input_data)
    if prediction:
        st.markdown(f"### Prediction Result: **{prediction}**")